/* This file is generated from prc_rename.def by genrename. */

/* This file is included only when prc_rename.h has been included. */
#ifdef TOPPERS_PRC_RENAME_H
#undef TOPPERS_PRC_RENAME_H

#undef start_dispatch
#undef exit_and_dispatch
#undef call_exit_kernel
#undef intnest
#undef current_intpri
#undef lock_flag
#undef default_int_handler
#undef default_exc_handler
#undef start_r
#undef dispatch
#undef start_dispatch
#undef x_config_int

#ifdef TOPPERS_LABEL_ASM

#undef _start_dispatch
#undef _exit_and_dispatch
#undef _call_exit_kernel
#undef _intnest
#undef _current_intpri
#undef _lock_flag
#undef _default_int_handler
#undef _default_exc_handler
#undef _start_r
#undef _dispatch
#undef _start_dispatch
#undef _x_config_int

#endif /* TOPPERS_LABEL_ASM */


#endif /* TOPPERS_PRC_RENAME_H */
